# Classes and Objects

- [Classes and Objects](Class)
- [Setters and Getters](Setters%20and%20Getters)
- [Constructors](Constructors)
- [Destructors](Destructors)
- [Functions of Objects](Functions%20of%20Objects)
- [Pointers to Objects](Pointers%20to%20Objects)
