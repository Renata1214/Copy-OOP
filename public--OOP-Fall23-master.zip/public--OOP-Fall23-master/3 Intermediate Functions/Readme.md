# Advanced Functions

1. [Inline Functions](Inline%20Functions)
2. [Recursion](Recursions)
3. [Function Overloading](Function%20Overloading)
4. [Function Template](Function%20Template)
5. [Namespaces](Namespaces)
6. [Files and Streams](Files%20and%20Streams)

