#ifndef FUNCTION_H 
#define FUNCTION_H 

int factorial(int); 
void print(std::string);
  
#endif
