#include <iostream>
#include<string> 
using namespace std; 
  
void print(string str) { 
    cout << str << "\n"; 
}
